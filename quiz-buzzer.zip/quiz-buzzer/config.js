import firebase from "firebase"

var firebaseConfig = {
    apiKey: "AIzaSyA4c5Jmee5dUvzn5z6hackNf5XnjVmlEks",
    authDomain: "wireless-buzzer-game-2a21c.firebaseapp.com",
    databaseURL: "https://wireless-buzzer-game-2a21c-default-rtdb.firebaseio.com",
    projectId: "wireless-buzzer-game-2a21c",
    storageBucket: "wireless-buzzer-game-2a21c.appspot.com",
    messagingSenderId: "356070859850",
    appId: "1:356070859850:web:ab0b68d65f49f2a4c972b3",
    measurementId: "G-E9BNX59LGX"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

  export default firebase.database()